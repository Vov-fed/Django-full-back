from rest_framework import viewsets, status
from .models import Article, Comment
from .serializers import ArticleSerializer, CommentSerializer
from rest_framework.permissions import IsAuthenticatedOrReadOnly, AllowAny
from .permissions import IsAdminOrReadOnly, IsOwnerOrAdmin
from django.contrib.auth.models import User
from rest_framework import generics
from rest_framework.serializers import ModelSerializer
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied

from rest_framework import filters
from rest_framework.permissions import IsAdminUser


from rest_framework import filters
    
class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]  # Admin-only creation
    filter_backends = [filters.SearchFilter]
    search_fields = ['title', 'content', 'tags', 'author__username']

    def perform_create(self, serializer):
        if self.request.user.is_staff:
            serializer.save(author=self.request.user)
        else:
            raise PermissionDenied("Only admins can create articles.")

class CommentViewSet(viewsets.ModelViewSet):
    serializer_class = CommentSerializer
    permission_classes = [IsAuthenticatedOrReadOnly, IsOwnerOrAdmin]

    def get_queryset(self):
        article_id = self.kwargs.get('article_pk')
        if article_id:
            return Comment.objects.filter(article_id=article_id)
        return Comment.objects.all()

    def perform_create(self, serializer):
        serializer.save(user=self.request.user, article_id=self.kwargs.get('article_pk'))

    def partial_update(self, request, *args, **kwargs):
        comment = self.get_object()
        if comment.user != request.user and not request.user.is_staff:
            return Response({"detail": "Not authorized to edit this comment."}, status=status.HTTP_403_FORBIDDEN)
        return super().partial_update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        comment = self.get_object()
        if comment.user != request.user and not request.user.is_staff:
            return Response({"detail": "Not authorized to delete this comment."}, status=status.HTTP_403_FORBIDDEN)
        return super().destroy(request, *args, **kwargs)

class RegisterSerializer(ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            password=validated_data['password']
        )
        return user

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]