import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import axios from 'axios'
import {jwtDecode} from 'jwt-decode'

function ArticleDetail() {
  const { id } = useParams()
  const [article, setArticle] = useState(null)
  const [comments, setComments] = useState([])
  const [newComment, setNewComment] = useState('')
  const [editCommentId, setEditCommentId] = useState(null)
  const [editContent, setEditContent] = useState('')
  const token = localStorage.getItem('access')
  const decoded = token ? jwtDecode(token) : null
  const currentUsername = decoded?.username

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch both article and comments
        const [articleRes, commentsRes] = await Promise.all([
          axios.get(`http://127.0.0.1:8000/api/articles/${id}/`),
          axios.get(`http://127.0.0.1:8000/api/articles/${id}/comments/`),
        ])
        setArticle(articleRes.data)
        setComments(commentsRes.data)
      } catch (err) {
        console.error('Error fetching article/comments', err)
      }
    }
    fetchData()
  }, [id])

  // CREATE a new comment
  const handleCommentSubmit = async (e) => {
    e.preventDefault()
    if (!token) return
    try {
        await axios.post(
            `http://127.0.0.1:8000/api/articles/${id}/comments/`,
            { content: newComment },
            {
              headers: { Authorization: `Bearer ${token}` },
            }
          )
      setNewComment('')
      // refresh comments
      const res = await axios.get(`http://127.0.0.1:8000/api/articles/${id}/comments/`)
      setComments(res.data)
    } catch (err) {
      console.error('Error posting comment', err)
    }
  }

  // Switch to "edit mode"
  const handleEdit = (comment) => {
    setEditCommentId(comment.id)
    setEditContent(comment.content)
  }

  const handleUpdate = async (e) => {
    e.preventDefault()
    try {
      await axios.patch(
        `http://127.0.0.1:8000/api/comments/${editCommentId}/`,
        { content: editContent },
        { headers: { Authorization: `Bearer ${token}` } }
      )
      setEditCommentId(null)
      setEditContent('')
      const res = await axios.get(`http://127.0.0.1:8000/api/articles/${id}/comments/`)
      setComments(res.data)
    } catch (err) {
      console.error('Update failed:', err)
    }
  }

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/comments/${id}/`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      setComments(comments.filter((c) => c.id !== id))
    } catch (err) {
      console.error('Delete failed:', err)
    }
  }
  
  const cancelEdit = () => {
    setEditCommentId(null)
    setEditContent('')
  }

  if (!article) return <p>Loading article...</p>

  return (
    <div className="container">
      <div className="article-box">
        <h2>{article.title}</h2>
        <p>{article.content}</p>
        <small>Author: {article.author}</small>
      </div>
      <hr />
      <h3>Comments</h3>
      {comments.map((comment) => (
        <div key={comment.id} className="comment-box">
          {editCommentId === comment.id ? (
            <form onSubmit={handleUpdate}>
              <textarea
                className="comment-textarea"
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
              />
              <br />
              <button type="submit" className="btn edit-btn">Save</button>
              <button onClick={() => cancelEdit()} className="btn delete-btn">Cancel</button>
            </form>
          ) : (
            <>
              <p>{comment.content}</p>
              <small>By {comment.user}</small>
              {currentUsername === comment.user && (
                <>
                  <br />
                  <button 
                    className="btn edit-btn"
                    onClick={() => handleEdit(comment)}>Edit</button>
                  <button
                    className="btn delete-btn"
                    onClick={() => handleDelete(comment.id)}>Delete</button>
                </>
              )}
            </>
          )}
        </div>
      ))}

      {token && (
        <form onSubmit={handleCommentSubmit} className="comment-form">
          <h4 className="comment-title">Add a Comment</h4>
          <textarea
            className="comment-textarea"
            placeholder="Write a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
          />
          <br />
          <button type="submit" className="btn">Post Comment</button>
        </form>
      )}
    </div>
  )
}

export default ArticleDetail