import { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

function Articles() {
  const [articles, setArticles] = useState([])
  const [query, setQuery] = useState('')

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const res = await axios.get(`http://127.0.0.1:8000/api/articles/?search=${query}`)
        setArticles(res.data)
      } catch (err) {
        console.error('Failed to fetch articles', err)
      }
    }

    fetchArticles()
  }, [query])

  return (
    <div className="container">
      <h2>Articles</h2>

      <input
        type="text"
        placeholder="Search..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="search-input"
        style={{ marginBottom: '1rem', padding: '0.5rem', width: '300px' }}
      />

      {articles.length === 0 ? (
        <p>No articles yet.</p>
      ) : (
        articles.map((article) => (
          <div key={article.id} className="article-preview" style={{ marginBottom: '2rem' }}>
            <Link to={`/articles/${article.id}`}>
              <h3>{article.title}</h3>
            </Link>
            <p>{article.content.slice(0, 200)}...</p>
            <small>
              By {article.author} on {new Date(article.published_at).toLocaleDateString()}
            </small>
            <br />
            <Link to={`/articles/${article.id}`} className="read-more">Read more →</Link>
          </div>
        ))
      )}
    </div>
  )
}

export default Articles