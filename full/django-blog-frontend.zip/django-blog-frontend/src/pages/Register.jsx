import { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

function Register() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const handleRegister = async (e) => {
    e.preventDefault()
    try {
      await axios.post('http://127.0.0.1:8000/api/register/', {
        username,
        password,
      })
      navigate('/login') // after success, go to login
    } catch (err) {
      setError('User already exists or invalid data')
    }
  }

  return (
    <div className="container">
      <h2>Register</h2>
      <form onSubmit={handleRegister} className="register-form">
        <input
          className="form-input"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        /><br /><br />
        <input
          type="password"
          className="form-input"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        /><br /><br />
        <button type="submit" className="btn">Register</button>
      </form>
      {error && <p className="error-msg">{error}</p>}
    </div>
  )
}

export default Register