import { Link, useNavigate } from 'react-router-dom'

function Navbar() {
  const navigate = useNavigate()
  const token = localStorage.getItem('access')

  const logout = () => {
    localStorage.removeItem('access')
    localStorage.removeItem('refresh')
    navigate('/login')
  }

  return (
    <nav className="navbar">
      <Link to="/" className="nav-link">Home</Link>
      {!token ? (
        <>
          <Link to="/login" className="nav-link">Login</Link>
          <Link to="/register" className="nav-link">Register</Link>
        </>
      ) : (
        <button onClick={logout} className="btn logout-btn">
          Logout
        </button>
      )}
    </nav>
  )
}

export default Navbar